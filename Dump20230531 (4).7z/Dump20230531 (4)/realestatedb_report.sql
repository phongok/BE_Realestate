-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: realestatedb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,3),(2,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,4),(3,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,5),(4,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,6),(5,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,7),(6,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,8),(7,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,9),(8,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,10),(9,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,11),(10,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,12),(11,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,13),(12,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,14),(13,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,15),(14,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,16),(15,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,17),(16,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,18),(17,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,19),(18,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,20),(19,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,21),(20,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Đã xác nhận',1,22),(21,'Sản phẩm không như giới thiệu, lừa đảo','2023-04-04','Chưa xác nhận',1,22),(22,'Lừa đảo, dụ dỗ khách hàng đặt cọc, mong admin xem xét','2023-04-30','Đã xác nhận',1,1),(23,'Lừa đảo ','2023-04-30','Đã xác nhận',1,1),(24,'Lừa đão','2023-04-30','Đã xác nhận',1,1),(25,'Lùa đảo siêu việt','2023-04-30','Chưa xác nhận',1,1),(26,'Sản phẩm không đung thực tế','2023-05-16','Chưa xem',1,1),(27,'','2023-05-24','Chưa xem',1,1),(28,'Sản phẩm không đúng thực tế','2023-05-24','Chưa xem',1,1),(29,'Giá cả sai thực tế','2023-05-24','Chưa xem',40,1),(30,'Giá không đúng sự thật, ảnh trên web không giống ảnh thực tế','2023-05-26','Chưa xem',46,1);
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 22:39:36
